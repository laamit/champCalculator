library(testthat)
library(champCalculator)

test_check("champCalculator")
